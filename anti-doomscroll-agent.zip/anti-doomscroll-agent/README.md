# Anti-Doomscroll AI Agent

AI-powered multi-agent productivity system.

## Features

- Multi-Agent Workflow
- Behavior Analysis
- Emotion Detection
- AI Intervention
- Long-term Memory
- Study Assistant

## Stack

- FastAPI
- React
- OpenAI API
- SQLite

## Run Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Run Frontend

```bash
cd frontend
npm install
npm run dev
```
