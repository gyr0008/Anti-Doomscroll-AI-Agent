import { useState } from 'react'
import axios from 'axios'

export default function App() {

  const [result, setResult] = useState(null)

  async function submit() {

    const res = await axios.post('http://127.0.0.1:8000/analyze', {
      app: 'TikTok',
      duration: 180,
      text: '我今天一直刷视频，不想学习'
    })

    setResult(res.data)
  }

  return (
    <div style={{padding:40,fontFamily:'sans-serif'}}>

      <h1>Anti Doomscroll AI Agent</h1>

      <button onClick={submit}>
        开始分析
      </button>

      {
        result && (
          <div>
            <h3>行为分析</h3>
            <p>{result.behavior}</p>

            <h3>情绪分析</h3>
            <p>{result.emotion}</p>

            <h3>AI 建议</h3>
            <p>{result.decision}</p>
          </div>
        )
      }

    </div>
  )
}
