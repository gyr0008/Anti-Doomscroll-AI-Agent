from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import declarative_base, sessionmaker

engine = create_engine("sqlite:///memory.db")
Session = sessionmaker(bind=engine)
Base = declarative_base()

class UserLog(Base):
    __tablename__ = "logs"

    id = Column(Integer, primary_key=True)
    app = Column(String)
    duration = Column(String)
    mood = Column(String)

Base.metadata.create_all(engine)
