from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

class BehaviorAgent:
    def analyze(self, app, duration):
        if duration > 120:
            return f"你今天在 {app} 上花费了太长时间。"
        return "使用时间正常。"

class EmotionAgent:
    def detect(self, text):
        prompt = f"判断用户是否焦虑或拖延：{text}"

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content

class DecisionAgent:
    def decide(self, behavior, emotion):
        prompt = f"根据以下信息给出干预建议：\n行为:{behavior}\n情绪:{emotion}"

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content
