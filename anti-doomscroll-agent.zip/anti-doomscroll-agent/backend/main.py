from fastapi import FastAPI
from pydantic import BaseModel
from agents import BehaviorAgent, EmotionAgent, DecisionAgent
from memory import Session, UserLog

app = FastAPI()

behavior_agent = BehaviorAgent()
emotion_agent = EmotionAgent()
decision_agent = DecisionAgent()

class InputData(BaseModel):
    app: str
    duration: int
    text: str

@app.post("/analyze")
def analyze(data: InputData):

    behavior = behavior_agent.analyze(data.app, data.duration)
    emotion = emotion_agent.detect(data.text)
    decision = decision_agent.decide(behavior, emotion)

    session = Session()

    log = UserLog(
        app=data.app,
        duration=str(data.duration),
        mood=emotion
    )

    session.add(log)
    session.commit()

    return {
        "behavior": behavior,
        "emotion": emotion,
        "decision": decision
    }
